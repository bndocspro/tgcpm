"""
Selenium / Undetected-Chromedriver Controller for Telegram Web Clone.
Handles session injection, dashboard verification, and humanized channel visit simulation.
"""

import os
import time
import random
import re
from typing import Dict, Any, Optional

# Clean outdated chromedriver paths from PATH so Selenium Manager automatically matches Chrome
if "PATH" in os.environ:
    os.environ["PATH"] = os.pathsep.join(
        [p for p in os.environ["PATH"].split(os.pathsep) if "SeleniumWebDrivers" not in p]
    )

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

try:
    import undetected_chromedriver as uc
    HAS_UC = True
except ImportError:
    HAS_UC = False

import config
from session_decoder import decode_string_session


class TelegramWebController:
    def __init__(self, headless: bool = False, proxy_url: Optional[str] = None):
        self.headless = headless
        self.proxy_url = proxy_url or config.PROXY_URL
        self.driver = self._create_driver()

    def _create_driver(self) -> webdriver.Chrome:
        """
        Initializes Chrome with anti-detection flags and custom configuration.
        """
        if HAS_UC and not self.headless:
            options = uc.ChromeOptions()
            options.set_capability("unhandledPromptBehavior", "accept")
            options.add_argument(f"--window-size={config.BROWSER_WINDOW_SIZE[0]},{config.BROWSER_WINDOW_SIZE[1]}")
            if config.USER_AGENT:
                options.add_argument(f"user-agent={config.USER_AGENT}")
            if self.proxy_url:
                options.add_argument(f"--proxy-server={self.proxy_url}")
            driver = uc.Chrome(options=options)
        else:
            # Fallback to standard Selenium Chrome driver
            options = Options()
            options.set_capability("unhandledPromptBehavior", "accept")
            if self.headless:
                options.add_argument("--headless=new")
            options.add_argument(f"--window-size={config.BROWSER_WINDOW_SIZE[0]},{config.BROWSER_WINDOW_SIZE[1]}")
            if config.USER_AGENT:
                options.add_argument(f"user-agent={config.USER_AGENT}")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option("useAutomationExtension", False)
            if self.proxy_url:
                options.add_argument(f"--proxy-server={self.proxy_url}")
            
            driver = webdriver.Chrome(options=options)
            
            # Patch navigator.webdriver in standard driver
            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"}
            )

        driver.set_page_load_timeout(30)
        driver.set_script_timeout(10)
        return driver

    def inject_session(self, session_string: str, user_id: str = "12345678", target_url: str = config.LOCAL_WEB_URL) -> bool:
        """
        Navigates to the local clone origin and executes dual-tier session injection.
        """
        print(f"[*] Navigating to local Telegram Web instance at {target_url}...")
        self.driver.get(target_url)
        time.sleep(2)  # Allow origin initialization

        # Decode StringSession
        decoded = decode_string_session(session_string)
        payload = {
            "dc_id": decoded["dc_id"],
            "auth_key_array": decoded["auth_key_list"],
            "auth_key_hex": decoded["auth_key_hex"],
            "user_id": str(user_id),
            "server_time_offset": 0
        }

        # Read injector script
        injector_path = os.path.join(os.path.dirname(__file__), "injector.js")
        with open(injector_path, "r", encoding="utf-8") as f:
            injector_script = f.read()

        print("[*] Executing dual-tier storage injection (IndexedDB + localStorage)...")
        try:
            result = self.driver.execute_async_script(injector_script, payload)
        except Exception as e:
            print(f"[!] Warning during script execution: {e}")
            # If async script timed out, verify if localStorage was written
            ls_check = self.driver.execute_script("return localStorage.getItem('account1');")
            if ls_check:
                result = {"success": True, "message": "localStorage written successfully"}
            else:
                result = {"success": False, "error": str(e)}

        print(f"[+] Injection Result: {result}")

        if not result or not result.get("success"):
            print(f"[!] Injection failed: {result}")
            return False

        print("[*] Refreshing browser page to initialize authenticated session...")
        self.driver.refresh()
        time.sleep(3)
        return True

    def wait_for_dashboard(self, timeout: int = 15) -> bool:
        """
        Verifies that the dashboard has rendered and the login screen was bypassed.
        """
        print("[*] Waiting for Telegram dashboard authentication state...")
        selectors = [
            "#middle-column",
            ".chat-list",
            ".Transition_slide-active",
            "#Main",
            ".sidebar-header"
        ]
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            # Safely check and dismiss any unexpected alert if Vite/Teact displayed one
            try:
                alert = self.driver.switch_to.alert
                alert_text = alert.text
                print(f"[!] Dismissing unexpected browser alert: {alert_text[:60]}...")
                alert.accept()
            except Exception:
                pass

            for selector in selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements and any(e.is_displayed() for e in elements):
                        print(f"[OK] Dashboard detected via selector: {selector}")
                        return True
                except Exception:
                    pass

            time.sleep(1)

        print("[!] Notice: Dashboard selector not confirmed yet. Session is active in browser.")
        return False

    def open_channel(self, channel_target: str, base_url: Optional[str] = None):
        """
        Opens a target channel or chat by formatting the navigation URL or hash.
        Supports:
        - "durov"
        - "@durov"
        - "https://t.me/durov"
        - "t.me/durov"
        """
        cleaned = channel_target.strip()
        # Extract username if given a URL
        match = re.search(r"(?:t\.me/|telegram\.me/|@)?([a-zA-Z0-9_]{4,})", cleaned)
        if match:
            username = match.group(1)
        else:
            username = cleaned.lstrip("@")

        if not base_url:
            current_url = self.driver.current_url
            if current_url and current_url.startswith("http"):
                from urllib.parse import urlparse
                parsed = urlparse(current_url)
                base_url = f"{parsed.scheme}://{parsed.netloc}"
            else:
                base_url = config.LOCAL_WEB_URL

        print(f"[*] Navigating to channel @{username}...")
        # Telegram Web A direct hashtag resolution format
        channel_web_url = f"{base_url.rstrip('/')}/#@{username}"
        self.driver.get(channel_web_url)
        time.sleep(1)

    def simulate_channel_reading(self, channel_target: str = "", duration_seconds: int = 30, base_url: Optional[str] = None):
        """
        Humanized Channel Visit & DOM Selector Scroll Simulation:
        - Automatically finds the active message container selector
        - Simulates natural human reading physics (variable velocity, smooth scroll)
        - 15% probability of backtracking / scrolling up to mimic re-reading
        - Random mouse cursor micro-drifts over message elements
        - Realistic reading pauses between scroll bursts
        """
        if channel_target:
            self.open_channel(channel_target, base_url=base_url)

        print(f"[*] Starting humanized reading simulation for {duration_seconds}s...")
        actions = ActionChains(self.driver)
        start_time = time.time()
        scroll_count = 0

        # JavaScript snippet to identify and scroll the active message container
        scroll_js = """
        function getScrollTarget() {
            const selectors = [
                '.MessageList',
                '.messages-layout',
                '.bubbles',
                '#middle-column .scrollable',
                '.history-full-height',
                '.chat-history',
                'main .scrollable',
                '.messages-container'
            ];
            for (const sel of selectors) {
                const el = document.querySelector(sel);
                if (el && el.scrollHeight > el.clientHeight) {
                    return { el: el, isWindow: false, selector: sel };
                }
            }
            return { el: document.scrollingElement || document.documentElement, isWindow: true, selector: 'window' };
        }

        const targetInfo = getScrollTarget();
        const delta = arguments[0];
        
        if (targetInfo.isWindow) {
            window.scrollBy({ top: delta, behavior: 'smooth' });
        } else {
            targetInfo.el.scrollBy({ top: delta, behavior: 'smooth' });
        }
        return targetInfo.selector;
        """

        while time.time() - start_time < duration_seconds:
            scroll_count += 1
            
            # 1. Decide scroll direction and magnitude
            # 85% forward scroll, 15% slight backward scroll (re-reading prior message)
            if scroll_count > 2 and random.random() < 0.15:
                # Scroll UP slightly
                delta = -random.randint(60, 150)
                scroll_type = "Rewind (Re-reading)"
            else:
                # Scroll DOWN naturally
                delta = random.randint(180, 420)
                scroll_type = "Reading Forward"

            active_selector = self.driver.execute_script(scroll_js, delta)

            # 2. Subtle cursor movement / drift over message bubbles
            if config.RANDOM_MOUSE_DRIFT:
                try:
                    # Hover over visible message elements if present
                    message_elements = self.driver.find_elements(By.CSS_SELECTOR, ".message-content, .bubble, .Message, .text-content")
                    if message_elements and random.random() < 0.4:
                        target_elem = random.choice(message_elements[-5:])
                        if target_elem.is_displayed():
                            actions.move_to_element(target_elem).perform()
                    else:
                        offset_x = random.randint(-25, 25)
                        offset_y = random.randint(-15, 15)
                        actions.move_by_offset(offset_x, offset_y).perform()
                except Exception:
                    pass

            # 3. Dynamic human reading pauses
            # Varies between quick glance (1.5s) and thorough reading (4.5s - 6.0s)
            pause_time = random.uniform(config.SCROLL_MIN_PAUSE, config.SCROLL_MAX_PAUSE)
            remaining = duration_seconds - (time.time() - start_time)
            actual_pause = min(pause_time, max(0.5, remaining))
            
            print(f"  [>] {scroll_type} ({delta:+d}px on {active_selector}) -> reading pause: {actual_pause:.1f}s")
            time.sleep(actual_pause)

        print("[OK] Channel visit simulation complete.")

    def close(self):
        """
        Closes browser instance safely without triggering the Web UI 'Log Out' action,
        thereby preserving the validity of the auth_key.
        """
        if self.driver:
            print("[*] Closing browser session safely (preserving server auth_key)...")
            try:
                self.driver.quit()
            except Exception as e:
                print(f"[!] Warning on driver quit: {e}")
            self.driver = None


if __name__ == "__main__":
    print("[*] Telegram Web Controller module loaded successfully.")
