"""
Main CLI Runner for Telegram Web Clone Session Injection and Automation.

Features:
- Automatic session validation: checks if an existing session is valid.
- First-time login generator: if no session exists or it is expired, prompts
  for phone number / OTP in the terminal via Telethon and saves to 'session.dat'.
- Full GUI browser automation: opens Chrome visibly on your screen.
- Humanized channel visit & DOM selector scroll simulation.

Usage Examples:
    # First time or normal run (uses session.dat or prompts login if missing):
    python run_session.py

    # With channel visit simulation:
    python run_session.py --channel "durov" --duration 30

    # With a specific session string:
    python run_session.py --session "1ApWapz..." --channel "@my_channel"
"""

import argparse
import asyncio
import sys

import config
from session_decoder import (
    decode_string_session,
    resolve_active_session,
    preflight_session_check,
    HAS_TELETHON
)
from browser_controller import TelegramWebController


def parse_args():
    parser = argparse.ArgumentParser(description="Telegram Web Clone Session Injector & Human Simulator")
    parser.add_argument(
        "--session", "-s",
        type=str,
        default=None,
        help="Optional Telethon StringSession. If omitted, checks session.dat or prompts first-time login."
    )
    parser.add_argument(
        "--session-file", "-f",
        type=str,
        default=config.SESSION_FILE,
        help=f"File path to store/read the session string (default: {config.SESSION_FILE})"
    )
    parser.add_argument(
        "--channel", "-c",
        type=str,
        default="",
        help="Channel username, link, or path to visit and simulate reading (e.g., 'durov' or '@durov')"
    )
    parser.add_argument(
        "--duration", "-d",
        type=int,
        default=30,
        help="Channel reading simulation duration in seconds (default: 30)"
    )
    parser.add_argument(
        "--url", "-u",
        type=str,
        default=config.LOCAL_WEB_URL,
        help=f"Local Telegram Web URL (default: {config.LOCAL_WEB_URL})"
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser in headless mode (default: False - visible GUI Chrome window)"
    )
    return parser.parse_args()


async def main():
    args = parse_args()

    print("=" * 70)
    print("TELEGRAM WEB CLONE AUTOMATION & HUMAN SIMULATOR")
    print("=" * 70)
    print(f"[*] API ID: {config.API_ID}")
    print(f"[*] Target Web Clone: {args.url}")
    print(f"[*] Mode: {'Headless (Hidden)' if args.headless else 'GUI (Visible Chrome Window)'}")
    print("-" * 70)

    # 1. Resolve and Validate Session
    try:
        session_string, user_id = await resolve_active_session(
            session_arg=args.session,
            session_file=args.session_file,
            api_id=config.API_ID,
            api_hash=config.API_HASH
        )
    except Exception as e:
        print(f"\n[!] Error resolving session: {e}")
        sys.exit(1)

    # 2. Decode MTProto connection parameters
    try:
        decoded = decode_string_session(session_string)
        print(f"\n[+] Active Session Configuration:")
        print(f"    - Target DC: {decoded['dc_id']}")
        print(f"    - Server Endpoint: {decoded['ip_address']}:{decoded['port']}")
        print(f"    - User ID: {user_id}")
        print(f"    - Auth Key Hash: {decoded['auth_key_hex'][:16]}... (256 bytes)")
    except Exception as e:
        print(f"[!] Failed to parse active session: {e}")
        sys.exit(1)

    # 3. Launch GUI Browser & Inject Session
    print("\n" + "-" * 70)
    print("[*] Launching Chrome Browser...")
    controller = TelegramWebController(headless=args.headless)
    
    try:
        success = controller.inject_session(session_string, user_id=user_id, target_url=args.url)
        if not success:
            print("[!] Storage injection failed. Please check the browser console for details.")
            return

        dashboard_ready = controller.wait_for_dashboard(timeout=15)
        if not dashboard_ready:
            print("[!] Notice: Dashboard selector not immediately spotted.")
            print("    Please check the local web clone page in the open browser window.")

        # 4. Humanized Channel Reading Simulation
        if args.channel:
            print("\n" + "-" * 70)
            controller.simulate_channel_reading(args.channel, duration_seconds=args.duration)

        print("\n" + "=" * 70)
        print("[OK] Session active in GUI browser!")
        print("     The browser window will remain open.")
        print("     Press Ctrl+C in this terminal to exit and close the browser safely.")
        print("=" * 70)

        # Keep browser open until user presses Ctrl+C
        try:
            while True:
                await asyncio.sleep(1)
        except (KeyboardInterrupt, asyncio.CancelledError):
            print("\n[*] Exiting on user interrupt...")

    finally:
        controller.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
