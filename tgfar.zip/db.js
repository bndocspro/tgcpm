/**
 * GitHub Action Runner - IndexedDB Storage Layer
 */
const DB_NAME = 'GitHubActionRunnerDB';
const DB_VERSION = 1;

let dbInstance = null;

function openDB() {
    return new Promise((resolve, reject) => {
        if (dbInstance) {
            return resolve(dbInstance);
        }

        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;

            // Accounts Store: stores { username, api_key, repos: [] }
            if (!db.objectStoreNames.contains('accounts')) {
                db.createObjectStore('accounts', { keyPath: 'username' });
            }

            // Settings Store: stores { key, value }
            if (!db.objectStoreNames.contains('settings')) {
                db.createObjectStore('settings', { keyPath: 'key' });
            }

            // Logs Store: stores { id, timestamp, account, repo, action, status, message, runUrl }
            if (!db.objectStoreNames.contains('logs')) {
                const logsStore = db.createObjectStore('logs', { keyPath: 'id', autoIncrement: true });
                logsStore.createIndex('timestamp', 'timestamp', { unique: false });
                logsStore.createIndex('account', 'account', { unique: false });
            }
        };

        request.onsuccess = (event) => {
            dbInstance = event.target.result;
            resolve(dbInstance);
        };

        request.onerror = (event) => {
            console.error('IndexedDB error:', event.target.error);
            reject(event.target.error);
        };
    });
}

// Account Operations
async function getAllAccounts() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('accounts', 'readonly');
        const store = tx.objectStore('accounts');
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
    });
}

async function getAccount(username) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('accounts', 'readonly');
        const store = tx.objectStore('accounts');
        const req = store.get(username);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function saveAccount(account) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('accounts', 'readwrite');
        const store = tx.objectStore('accounts');
        // Sanitize
        const cleanAccount = {
            username: (account.username || '').trim(),
            api_key: (account.api_key || '').trim(),
            repos: (account.repos || []).map(r => (r || '').trim()).filter(Boolean)
        };
        const req = store.put(cleanAccount);
        req.onsuccess = () => resolve(cleanAccount);
        req.onerror = () => reject(req.error);
    });
}

async function deleteAccount(username) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('accounts', 'readwrite');
        const store = tx.objectStore('accounts');
        const req = store.delete(username);
        req.onsuccess = () => resolve(true);
        req.onerror = () => reject(req.error);
    });
}

async function importAccountsFromJSON(jsonData) {
    if (!jsonData || !Array.isArray(jsonData.accounts)) {
        throw new Error('Invalid JSON format. Expected an object with an "accounts" array.');
    }
    const saved = [];
    for (const acc of jsonData.accounts) {
        if (acc.username) {
            const clean = await saveAccount(acc);
            saved.push(clean);
        }
    }
    return saved;
}

// Settings Operations
async function getSetting(key, defaultValue = null) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('settings', 'readonly');
        const store = tx.objectStore('settings');
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result ? req.result.value : defaultValue);
        req.onerror = () => reject(req.error);
    });
}

async function saveSetting(key, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('settings', 'readwrite');
        const store = tx.objectStore('settings');
        const req = store.put({ key, value });
        req.onsuccess = () => resolve(value);
        req.onerror = () => reject(req.error);
    });
}

// Logs Operations
async function addLog(logEntry) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('logs', 'readwrite');
        const store = tx.objectStore('logs');
        const entry = {
            timestamp: new Date().toISOString(),
            account: logEntry.account || '',
            repo: logEntry.repo || '',
            action: logEntry.action || 'DISPATCH',
            status: logEntry.status || 'INFO',
            message: logEntry.message || '',
            runUrl: logEntry.runUrl || ''
        };
        const req = store.add(entry);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function getRecentLogs(limit = 100) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('logs', 'readonly');
        const store = tx.objectStore('logs');
        const req = store.getAll();
        req.onsuccess = () => {
            const logs = req.result || [];
            logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
            resolve(logs.slice(0, limit));
        };
        req.onerror = () => reject(req.error);
    });
}

async function clearAllLogs() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction('logs', 'readwrite');
        const store = tx.objectStore('logs');
        const req = store.clear();
        req.onsuccess = () => resolve(true);
        req.onerror = () => reject(req.error);
    });
}
