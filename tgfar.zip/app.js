/**
 * GitHub Action Runner - Application Logic
 */

// State
let accounts = [];
let currentAccount = null;
let repoStatuses = {}; // { repoName: { status, conclusion, html_url, created_at, updated_at } }
let isRunnerRunning = false;
let isRunnerPaused = false;
let queueList = [];
let queueIndex = 0;
let countdownTimer = null;
let autoRefreshTimer = null;

// DOM Elements
const accountSelect = document.getElementById('accountSelect');
const activeAccountCard = document.getElementById('activeAccountCard');
const repoTableBody = document.getElementById('repoTableBody');
const selectAllCheckbox = document.getElementById('selectAllCheckbox');
const selectedCountBadge = document.getElementById('selectedCountBadge');
const totalRepoCountBadge = document.getElementById('totalRepoCountBadge');
const searchInput = document.getElementById('searchInput');

// Runner Controls
const btnTriggerSelected = document.getElementById('btnTriggerSelected');
const btnPauseRunner = document.getElementById('btnPauseRunner');
const btnStopRunner = document.getElementById('btnStopRunner');
const btnRefreshStatus = document.getElementById('btnRefreshStatus');
const delayInput = document.getElementById('delayInput');
const branchInput = document.getElementById('branchInput');
const workflowInput = document.getElementById('workflowInput');
const progressBarFill = document.getElementById('progressBarFill');
const progressText = document.getElementById('progressText');
const progressPercent = document.getElementById('progressPercent');

// Modals
const importModal = document.getElementById('importModal');
const accountModal = document.getElementById('accountModal');
const jsonImportInput = document.getElementById('jsonImportInput');
const logsConsole = document.getElementById('logsConsole');

// Toast container
const toastContainer = document.getElementById('toastContainer');

// --- Initialization ---
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await initApp();
    } catch (err) {
        showToast('Failed to initialize database: ' + err.message, 'error');
        console.error(err);
    }
});

async function initApp() {
    await openDB();
    await loadSettings();
    await refreshAccountList();

    // If no accounts exist in DB, try to pre-load from action_runner.json if accessible via fetch or preset
    if (accounts.length === 0) {
        try {
            const resp = await fetch('action_runner.json');
            if (resp.ok) {
                const data = await resp.json();
                await importAccountsFromJSON(data);
                await refreshAccountList();
                showToast('Auto-imported accounts from action_runner.json', 'success');
            }
        } catch (e) {
            console.log('No local action_runner.json fetched automatically');
        }
    }

    await loadLogsToUI();
    setupEventListeners();
}

// --- Settings Management ---
async function loadSettings() {
    const savedDelay = await getSetting('delaySeconds', 5);
    const savedBranch = await getSetting('defaultBranch', 'main');
    const savedWorkflow = await getSetting('workflowFile', 'main.yml');

    if (delayInput) delayInput.value = savedDelay;
    if (branchInput) branchInput.value = savedBranch;
    if (workflowInput) workflowInput.value = savedWorkflow;
}

// --- Account Management ---
async function refreshAccountList() {
    accounts = await getAllAccounts();
    accountSelect.innerHTML = '';

    if (accounts.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '-- No Accounts Found (Import JSON) --';
        accountSelect.appendChild(opt);
        currentAccount = null;
        renderActiveAccountInfo();
        renderRepoTable();
        return;
    }

    accounts.forEach(acc => {
        const opt = document.createElement('option');
        opt.value = acc.username;
        opt.textContent = `${acc.username} (${acc.repos.length} repos)`;
        accountSelect.appendChild(opt);
    });

    const savedUsername = await getSetting('selectedUsername', accounts[0]?.username);
    const match = accounts.find(a => a.username === savedUsername) || accounts[0];
    
    if (match) {
        accountSelect.value = match.username;
        currentAccount = match;
    }

    renderActiveAccountInfo();
    renderRepoTable();
    fetchStatusesForAccount();
}

function renderActiveAccountInfo() {
    if (!currentAccount) {
        activeAccountCard.innerHTML = `
            <div style="text-align: center; color: var(--text-muted); padding: 16px;">
                No active account selected. Click <b>"Import JSON"</b> or <b>"Add Account"</b> to get started.
            </div>
        `;
        return;
    }

    const maskedKey = currentAccount.api_key ? 
        (currentAccount.api_key.substring(0, 7) + '...' + currentAccount.api_key.substring(currentAccount.api_key.length - 4)) : 
        'Not configured';

    activeAccountCard.innerHTML = `
        <div class="account-info-row">
            <span style="color: var(--text-muted);">Username:</span>
            <span style="font-weight: 600; color: #a5b4fc;">${escapeHtml(currentAccount.username)}</span>
        </div>
        <div class="account-info-row">
            <span style="color: var(--text-muted);">Token:</span>
            <code style="font-family: var(--font-mono); font-size: 0.75rem; color: #67e8f9;">${escapeHtml(maskedKey)}</code>
        </div>
        <div class="account-info-row">
            <span style="color: var(--text-muted);">Repositories:</span>
            <span class="account-stat-pill">${currentAccount.repos.length} Total</span>
        </div>
        <div style="display: flex; gap: 8px; margin-top: 6px;">
            <button class="btn btn-secondary btn-sm" onclick="openEditAccountModal()" style="flex: 1;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                Edit
            </button>
            <button class="btn btn-rose btn-sm" onclick="handleDeleteCurrentAccount()">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
        </div>
    `;
}

// --- Repositories Table Rendering ---
function renderRepoTable() {
    if (!currentAccount || !currentAccount.repos || currentAccount.repos.length === 0) {
        repoTableBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 32px;">
                    No repositories available for this account.
                </td>
            </tr>
        `;
        totalRepoCountBadge.textContent = '0 repos';
        updateSelectedCount();
        return;
    }

    const filterQuery = (searchInput.value || '').toLowerCase().trim();
    const filteredRepos = currentAccount.repos.filter(r => r.toLowerCase().includes(filterQuery));

    totalRepoCountBadge.textContent = `${filteredRepos.length} repos`;

    let html = '';
    filteredRepos.forEach((repoName, idx) => {
        const repoStatus = repoStatuses[repoName] || {};
        const statusBadge = getStatusBadgeHTML(repoStatus);
        const lastRunInfo = formatLastRunInfo(repoStatus);

        html += `
            <tr data-repo="${escapeHtml(repoName)}">
                <td style="width: 40px; text-align: center;">
                    <input type="checkbox" class="custom-checkbox repo-checkbox" value="${escapeHtml(repoName)}" onchange="updateSelectedCount()" checked>
                </td>
                <td style="width: 50px; color: var(--text-dim); font-size: 0.8rem;">
                    #${idx + 1}
                </td>
                <td>
                    <div class="repo-name-cell">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--accent-primary); flex-shrink: 0;"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                        <a href="https://github.com/${encodeURIComponent(currentAccount.username)}/${encodeURIComponent(repoName)}" target="_blank" class="repo-link">
                            ${escapeHtml(repoName)}
                        </a>
                    </div>
                </td>
                <td>
                    <div id="status-${escapeHtml(repoName)}">
                        ${statusBadge}
                    </div>
                </td>
                <td style="font-size: 0.8rem; color: var(--text-muted);">
                    <div id="runinfo-${escapeHtml(repoName)}">
                        ${lastRunInfo}
                    </div>
                </td>
                <td style="text-align: right;">
                    <button class="btn btn-secondary btn-sm" onclick="triggerSingleRepo('${escapeHtml(repoName)}')" title="Trigger this action immediately">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        Run
                    </button>
                </td>
            </tr>
        `;
    });

    repoTableBody.innerHTML = html;
    updateSelectedCount();
}

function getStatusBadgeHTML(repoStatus) {
    if (!repoStatus || !repoStatus.status) {
        return `<span class="status-badge status-idle">Idle</span>`;
    }

    if (repoStatus.status === 'in_progress') {
        return `<span class="status-badge status-in_progress">Running</span>`;
    }
    if (repoStatus.status === 'queued') {
        return `<span class="status-badge status-queued">Queued</span>`;
    }
    if (repoStatus.status === 'completed') {
        if (repoStatus.conclusion === 'success') {
            return `<span class="status-badge status-success">Success</span>`;
        } else if (repoStatus.conclusion === 'failure') {
            return `<span class="status-badge status-failure">Failed</span>`;
        } else {
            return `<span class="status-badge status-idle">${escapeHtml(repoStatus.conclusion || 'Completed')}</span>`;
        }
    }

    return `<span class="status-badge status-idle">${escapeHtml(repoStatus.status)}</span>`;
}

function formatLastRunInfo(repoStatus) {
    if (!repoStatus || !repoStatus.created_at) {
        return '<span style="color: var(--text-dim);">-</span>';
    }
    const date = new Date(repoStatus.created_at);
    const timeAgo = formatTimeAgo(date);
    const runLink = repoStatus.html_url ? 
        `<a href="${repoStatus.html_url}" target="_blank" style="color: var(--accent-cyan); text-decoration: none; margin-left: 6px;">#${repoStatus.run_number || 'View'} ↗</a>` : '';
    return `<span>${timeAgo}</span>${runLink}`;
}

function updateSelectedCount() {
    const checkboxes = document.querySelectorAll('.repo-checkbox');
    const checked = document.querySelectorAll('.repo-checkbox:checked');
    selectedCountBadge.textContent = `${checked.length} Selected`;

    if (selectAllCheckbox) {
        selectAllCheckbox.checked = (checkboxes.length > 0 && checked.length === checkboxes.length);
        selectAllCheckbox.indeterminate = (checked.length > 0 && checked.length < checkboxes.length);
    }
}

// --- GitHub API Calls ---
async function fetchStatusesForAccount() {
    if (!currentAccount || !currentAccount.repos || currentAccount.repos.length === 0) return;

    for (const repoName of currentAccount.repos) {
        try {
            const res = await fetch(`https://api.github.com/repos/${encodeURIComponent(currentAccount.username)}/${encodeURIComponent(repoName)}/actions/runs?per_page=1`, {
                headers: {
                    'Authorization': `Bearer ${currentAccount.api_key}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });

            if (res.ok) {
                const data = await res.json();
                if (data.workflow_runs && data.workflow_runs.length > 0) {
                    const run = data.workflow_runs[0];
                    repoStatuses[repoName] = {
                        status: run.status,
                        conclusion: run.conclusion,
                        html_url: run.html_url,
                        created_at: run.created_at,
                        updated_at: run.updated_at,
                        run_number: run.run_number
                    };

                    // Update row UI dynamically
                    const statusEl = document.getElementById(`status-${repoName}`);
                    const runInfoEl = document.getElementById(`runinfo-${repoName}`);
                    if (statusEl) statusEl.innerHTML = getStatusBadgeHTML(repoStatuses[repoName]);
                    if (runInfoEl) runInfoEl.innerHTML = formatLastRunInfo(repoStatuses[repoName]);
                }
            }
        } catch (e) {
            console.error(`Status check failed for ${repoName}:`, e);
        }
    }
}

async function dispatchWorkflow(repoName, branch = 'main', workflow = 'main.yml') {
    if (!currentAccount) throw new Error('No active account selected.');
    if (!currentAccount.api_key) throw new Error(`Missing GitHub API key for ${currentAccount.username}`);

    const url = `https://api.github.com/repos/${encodeURIComponent(currentAccount.username)}/${encodeURIComponent(repoName)}/actions/workflows/${encodeURIComponent(workflow)}/dispatches`;

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${currentAccount.api_key}`,
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ref: branch })
    });

    if (res.status === 204) {
        // Success
        return { success: true };
    } else {
        let errorMsg = `HTTP ${res.status}`;
        try {
            const errData = await res.json();
            if (errData.message) errorMsg += `: ${errData.message}`;
        } catch (e) {}
        throw new Error(errorMsg);
    }
}

// --- Runner Execution Queue ---
async function startBatchTrigger() {
    const checkedBoxes = Array.from(document.querySelectorAll('.repo-checkbox:checked'));
    if (checkedBoxes.length === 0) {
        showToast('Please select at least one repository to trigger.', 'warning');
        return;
    }

    if (!currentAccount || !currentAccount.api_key) {
        showToast('Active account missing API Key / Token.', 'error');
        return;
    }

    queueList = checkedBoxes.map(cb => cb.value);
    queueIndex = 0;
    isRunnerRunning = true;
    isRunnerPaused = false;

    // Save inputs
    const delaySec = Math.max(0, parseInt(delayInput.value) || 0);
    const branch = branchInput.value.trim() || 'main';
    const workflow = workflowInput.value.trim() || 'main.yml';

    await saveSetting('delaySeconds', delaySec);
    await saveSetting('defaultBranch', branch);
    await saveSetting('workflowFile', workflow);

    updateRunnerControlsUI();
    showToast(`Started queue: ${queueList.length} repositories with ${delaySec}s delay.`, 'success');
    appendLog('INFO', currentAccount.username, '-', `Batch run started for ${queueList.length} repositories.`);

    runNextInQueue();
}

async function runNextInQueue() {
    if (!isRunnerRunning) return;

    if (isRunnerPaused) {
        progressText.textContent = 'Queue Paused';
        return;
    }

    if (queueIndex >= queueList.length) {
        // Completed
        isRunnerRunning = false;
        isRunnerPaused = false;
        updateRunnerControlsUI();
        progressBarFill.style.width = '100%';
        progressText.textContent = 'All Completed!';
        progressPercent.textContent = '100%';
        showToast('Batch trigger queue finished successfully!', 'success');
        appendLog('SUCCESS', currentAccount.username, '-', 'All selected repositories processed.');
        // Refresh statuses
        setTimeout(fetchStatusesForAccount, 3000);
        return;
    }

    const repoName = queueList[queueIndex];
    const total = queueList.length;
    const currentNum = queueIndex + 1;
    const percent = Math.round(((currentNum - 1) / total) * 100);

    progressBarFill.style.width = `${percent}%`;
    progressPercent.textContent = `${percent}%`;
    progressText.textContent = `Triggering ${repoName} (${currentNum}/${total})...`;

    const statusEl = document.getElementById(`status-${repoName}`);
    if (statusEl) {
        statusEl.innerHTML = `<span class="status-badge status-in_progress">Triggering...</span>`;
    }

    const branch = branchInput.value.trim() || 'main';
    const workflow = workflowInput.value.trim() || 'main.yml';

    try {
        await dispatchWorkflow(repoName, branch, workflow);
        appendLog('SUCCESS', currentAccount.username, repoName, `Successfully dispatched workflow '${workflow}' [${branch}]`);
        if (statusEl) {
            statusEl.innerHTML = `<span class="status-badge status-queued">Dispatched</span>`;
        }
    } catch (err) {
        appendLog('ERROR', currentAccount.username, repoName, `Failed to dispatch: ${err.message}`);
        if (statusEl) {
            statusEl.innerHTML = `<span class="status-badge status-failure">Error</span>`;
        }
    }

    queueIndex++;

    if (queueIndex < total && isRunnerRunning) {
        const delaySec = Math.max(0, parseInt(delayInput.value) || 0);
        if (delaySec > 0) {
            let remaining = delaySec;
            progressText.textContent = `Waiting delay (${remaining}s) before next repo...`;
            
            countdownTimer = setInterval(() => {
                if (!isRunnerRunning || isRunnerPaused) {
                    clearInterval(countdownTimer);
                    return;
                }
                remaining--;
                if (remaining > 0) {
                    progressText.textContent = `Waiting delay (${remaining}s) before next repo...`;
                } else {
                    clearInterval(countdownTimer);
                    runNextInQueue();
                }
            }, 1000);
        } else {
            runNextInQueue();
        }
    } else {
        runNextInQueue();
    }
}

function pauseRunner() {
    if (!isRunnerRunning) return;
    isRunnerPaused = !isRunnerPaused;
    if (isRunnerPaused) {
        if (countdownTimer) clearInterval(countdownTimer);
        btnPauseRunner.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg> Resume`;
        progressText.textContent = 'Queue Paused';
        appendLog('WAIT', currentAccount?.username || '-', '-', 'Queue paused by user.');
    } else {
        btnPauseRunner.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> Pause`;
        appendLog('INFO', currentAccount?.username || '-', '-', 'Queue resumed.');
        runNextInQueue();
    }
}

function stopRunner() {
    isRunnerRunning = false;
    isRunnerPaused = false;
    if (countdownTimer) clearInterval(countdownTimer);
    updateRunnerControlsUI();
    progressText.textContent = 'Stopped';
    appendLog('WAIT', currentAccount?.username || '-', '-', 'Queue stopped by user.');
    showToast('Queue stopped.', 'warning');
}

function updateRunnerControlsUI() {
    btnTriggerSelected.disabled = isRunnerRunning;
    btnPauseRunner.disabled = !isRunnerRunning;
    btnStopRunner.disabled = !isRunnerRunning;

    if (!isRunnerRunning) {
        btnPauseRunner.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> Pause`;
    }
}

async function triggerSingleRepo(repoName) {
    if (!currentAccount || !currentAccount.api_key) {
        showToast('Missing API key for active account.', 'error');
        return;
    }

    const branch = branchInput.value.trim() || 'main';
    const workflow = workflowInput.value.trim() || 'main.yml';

    const statusEl = document.getElementById(`status-${repoName}`);
    if (statusEl) {
        statusEl.innerHTML = `<span class="status-badge status-in_progress">Triggering...</span>`;
    }

    try {
        await dispatchWorkflow(repoName, branch, workflow);
        showToast(`Triggered ${repoName} (${workflow}) successfully!`, 'success');
        appendLog('SUCCESS', currentAccount.username, repoName, `Single dispatch triggered [${workflow}]`);
        if (statusEl) {
            statusEl.innerHTML = `<span class="status-badge status-queued">Dispatched</span>`;
        }
    } catch (e) {
        showToast(`Failed for ${repoName}: ${e.message}`, 'error');
        appendLog('ERROR', currentAccount.username, repoName, `Single dispatch failed: ${e.message}`);
        if (statusEl) {
            statusEl.innerHTML = `<span class="status-badge status-failure">Error</span>`;
        }
    }
}

// --- Console Logs Handling ---
async function appendLog(status, account, repo, message, runUrl = '') {
    const logEntry = {
        timestamp: new Date().toISOString(),
        status,
        account,
        repo,
        message,
        runUrl
    };

    // Save to DB
    await addLog(logEntry);

    // Append to UI
    renderSingleLogEntry(logEntry, true);
}

function renderSingleLogEntry(entry, prepend = false) {
    const timeStr = new Date(entry.timestamp).toLocaleTimeString();
    const div = document.createElement('div');
    div.className = 'log-entry';
    div.innerHTML = `
        <span class="log-time">[${timeStr}]</span>
        <span class="log-tag log-tag-${escapeHtml(entry.status)}">${escapeHtml(entry.status)}</span>
        <span style="color: #a5b4fc; font-weight: 500;">${escapeHtml(entry.account || '')}</span>
        ${entry.repo && entry.repo !== '-' ? `<span style="color: var(--accent-cyan);">[${escapeHtml(entry.repo)}]</span>` : ''}
        <span class="log-msg">${escapeHtml(entry.message)}</span>
    `;

    if (prepend && logsConsole.firstChild) {
        logsConsole.insertBefore(div, logsConsole.firstChild);
    } else {
        logsConsole.appendChild(div);
    }
}

async function loadLogsToUI() {
    logsConsole.innerHTML = '';
    const logs = await getRecentLogs(50);
    logs.forEach(entry => renderSingleLogEntry(entry, false));
}

async function handleClearLogs() {
    await clearAllLogs();
    logsConsole.innerHTML = '<div style="color: var(--text-dim); text-align: center; padding: 12px;">Logs cleared</div>';
    showToast('Logs cleared.', 'success');
}

// --- Modals Management ---
function openImportModal() {
    jsonImportInput.value = '';
    importModal.classList.add('active');
}

function closeImportModal() {
    importModal.classList.remove('active');
}

async function handleImportSubmit() {
    const raw = jsonImportInput.value.trim();
    if (!raw) {
        showToast('Please paste valid JSON data.', 'warning');
        return;
    }

    try {
        const parsed = JSON.parse(raw);
        const imported = await importAccountsFromJSON(parsed);
        closeImportModal();
        await refreshAccountList();
        showToast(`Successfully imported ${imported.length} accounts to IndexedDB!`, 'success');
    } catch (e) {
        showToast('JSON Import Error: ' + e.message, 'error');
    }
}

function handleJSONFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        jsonImportInput.value = event.target.result;
    };
    reader.readAsText(file);
}

function openAddAccountModal() {
    document.getElementById('modalAccountTitle').textContent = 'Add Account';
    document.getElementById('accUsernameInput').value = '';
    document.getElementById('accApiKeyInput').value = '';
    document.getElementById('accReposInput').value = '';
    document.getElementById('accUsernameInput').disabled = false;
    accountModal.classList.add('active');
}

function openEditAccountModal() {
    if (!currentAccount) return;
    document.getElementById('modalAccountTitle').textContent = 'Edit Account';
    document.getElementById('accUsernameInput').value = currentAccount.username;
    document.getElementById('accApiKeyInput').value = currentAccount.api_key;
    document.getElementById('accReposInput').value = (currentAccount.repos || []).join('\n');
    document.getElementById('accUsernameInput').disabled = true; // username is key
    accountModal.classList.add('active');
}

function closeAccountModal() {
    accountModal.classList.remove('active');
}

async function handleSaveAccountSubmit() {
    const username = document.getElementById('accUsernameInput').value.trim();
    const apiKey = document.getElementById('accApiKeyInput').value.trim();
    const reposRaw = document.getElementById('accReposInput').value.trim();

    if (!username) {
        showToast('Username is required.', 'warning');
        return;
    }

    const reposList = reposRaw.split(/[\n,]+/).map(r => r.trim()).filter(Boolean);

    const accountObj = {
        username,
        api_key: apiKey,
        repos: reposList
    };

    await saveAccount(accountObj);
    closeAccountModal();
    await refreshAccountList();
    showToast(`Account '${username}' saved!`, 'success');
}

async function handleDeleteCurrentAccount() {
    if (!currentAccount) return;
    if (confirm(`Are you sure you want to delete account '${currentAccount.username}' and its repos from IndexedDB?`)) {
        await deleteAccount(currentAccount.username);
        showToast(`Account '${currentAccount.username}' deleted.`, 'success');
        await refreshAccountList();
    }
}

// --- Event Listeners Setup ---
function setupEventListeners() {
    accountSelect.addEventListener('change', async (e) => {
        const un = e.target.value;
        currentAccount = accounts.find(a => a.username === un) || null;
        await saveSetting('selectedUsername', un);
        renderActiveAccountInfo();
        renderRepoTable();
        fetchStatusesForAccount();
    });

    selectAllCheckbox.addEventListener('change', (e) => {
        const isChecked = e.target.checked;
        document.querySelectorAll('.repo-checkbox').forEach(cb => {
            cb.checked = isChecked;
        });
        updateSelectedCount();
    });

    searchInput.addEventListener('input', () => {
        renderRepoTable();
    });

    btnTriggerSelected.addEventListener('click', startBatchTrigger);
    btnPauseRunner.addEventListener('click', pauseRunner);
    btnStopRunner.addEventListener('click', stopRunner);
    btnRefreshStatus.addEventListener('click', async () => {
        showToast('Fetching latest GitHub Actions statuses...', 'info');
        await fetchStatusesForAccount();
        showToast('Statuses updated.', 'success');
    });

    // Auto-refresh interval toggle
    const autoRefreshCheckbox = document.getElementById('autoRefreshCheckbox');
    if (autoRefreshCheckbox) {
        autoRefreshCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                autoRefreshTimer = setInterval(fetchStatusesForAccount, 12000);
                showToast('Auto-refresh enabled (every 12s)', 'info');
            } else {
                if (autoRefreshTimer) clearInterval(autoRefreshTimer);
                showToast('Auto-refresh disabled', 'info');
            }
        });
    }
}

// --- Helper Utilities ---
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function formatTimeAgo(date) {
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}
