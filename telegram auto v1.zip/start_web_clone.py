"""
Helper script to start the local official Telegram Web A clone.
Runs the Vite development server on http://localhost:8080.
"""

import os
import subprocess
import sys

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    web_dir = os.path.join(base_dir, "telegram-web")

    if not os.path.exists(web_dir):
        print(f"[!] Error: '{web_dir}' does not exist.")
        sys.exit(1)

    print("=" * 65)
    print("STARTING LOCAL OFFICIAL TELEGRAM WEB A CLONE")
    print("=" * 65)
    print(f"[*] Directory: {web_dir}")
    print("[*] Serving on: http://localhost:8080")
    print("[*] Press Ctrl+C to stop the dev server.")
    print("-" * 65)

    try:
        # Run npm run dev with port 8080 and host 127.0.0.1
        subprocess.run(
            "npm run dev -- --port 8080 --host 127.0.0.1",
            shell=True,
            cwd=web_dir,
            check=True
        )
    except KeyboardInterrupt:
        print("\n[*] Stopping local Telegram Web clone...")
    except subprocess.CalledProcessError as e:
        print(f"[!] Dev server exited with code: {e.returncode}")


if __name__ == "__main__":
    main()
