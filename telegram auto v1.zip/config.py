"""
Configuration Module for Telegram Client Automation and Session Injection System.
Set your official Telegram API credentials and local clone endpoints here.
"""

import os

# Telegram MTProto API Credentials (from https://my.telegram.org)
# Note: The local Telegram Web clone must be compiled with the SAME api_id and api_hash.
API_ID = int(os.getenv("TELEGRAM_API_ID", "34360444"))  # Replace with your actual api_id
API_HASH = os.getenv("TELEGRAM_API_HASH", "78874fe5f0bf1aba4fd15a3b6ec45b11")  # Replace with your actual api_hash

# Local Telegram Web Clone Endpoint
LOCAL_WEB_URL = os.getenv("LOCAL_WEB_URL", "https://ngram.pages.dev")

# Default Session Storage File
SESSION_FILE = os.getenv("TELEGRAM_SESSION_FILE", "session.dat")

# Channel Visit List Source (Remote Cloudflare Pages URL or Local File)
CHANNELS_SOURCE_URL = os.getenv("CHANNELS_SOURCE_URL", "https://chvisit.pages.dev/chvisit.json")

# Browser Configuration
BROWSER_WINDOW_SIZE = (1280, 800)
# Browser User-Agent:
# When set to None (default), the browser uses its authentic native User-Agent matching
# its installed version (Chrome 153+) and Client Hints (Sec-CH-UA). This eliminates
# the "Inconsistent Fingerprint" alert on Pixelscan and anti-bot systems.
USER_AGENT = os.getenv("TELEGRAM_USER_AGENT", None)

# Optional Proxy Configuration (Format: 'socks5://user:pass@ip:port' or None)
PROXY_URL = os.getenv("TELEGRAM_PROXY_URL", None)

# Simulation & Anti-Ban Parameters
SCROLL_MIN_PAUSE = 2.0
SCROLL_MAX_PAUSE = 5.5
RANDOM_MOUSE_DRIFT = True
