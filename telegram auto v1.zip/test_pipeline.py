"""
Automated Test Suite for Telegram Web Session Injection Pipeline.
Validates session decoding, headless browser execution, dual-tier storage injection,
and DOM action execution.
"""

import os
import json
import base64
import time
from session_decoder import encode_string_session, decode_string_session
from browser_controller import TelegramWebController

def run_tests():
    print("==================================================================")
    print("TEST SUITE: TELEGRAM SESSION INJECTION & AUTOMATION PIPELINE")
    print("==================================================================")

    # -------------------------------------------------------------
    # 1. Test Session Decoder (IPv4 & IPv6)
    # -------------------------------------------------------------
    print("\n[TEST 1] Testing Session Decoder Unpacking...")
    dummy_key = os.urandom(256)
    dummy_session_v4 = encode_string_session(2, "149.154.167.51", 443, dummy_key)
    decoded_v4 = decode_string_session(dummy_session_v4)
    assert decoded_v4["dc_id"] == 2
    assert decoded_v4["ip_address"] == "149.154.167.51"
    assert decoded_v4["port"] == 443
    assert decoded_v4["auth_key_bytes"] == dummy_key
    print("  [OK] IPv4 StringSession packed & unpacked correctly.")

    dummy_session_v6 = encode_string_session(4, "2001:b28:f23d:f001::a", 443, dummy_key)
    decoded_v6 = decode_string_session(dummy_session_v6)
    assert decoded_v6["dc_id"] == 4
    assert decoded_v6["port"] == 443
    assert decoded_v6["auth_key_bytes"] == dummy_key
    print("  [OK] IPv6 StringSession packed & unpacked correctly.")

    # -------------------------------------------------------------
    # 2. Test Browser Controller & Dual-Tier Storage Injection
    # -------------------------------------------------------------
    print("\n[TEST 2] Testing Headless Browser & Dual-Tier Injection...")
    
    # Start temporary local HTTP server to provide a legitimate web origin for IndexedDB/localStorage
    import http.server
    import socketserver
    import threading

    class TestHandler(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            html = """<!DOCTYPE html>
            <html>
            <head><title>Telegram Web Test Clone</title></head>
            <body>
                <div id="middle-column">
                    <div class="chat-list">Active Chat List</div>
                </div>
            </body>
            </html>"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))
        def log_message(self, format, *args):
            pass  # silence logs

    server = socketserver.TCPServer(("127.0.0.1", 8999), TestHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    print("  [+] Local test HTTP server started on http://127.0.0.1:8999")

    controller = TelegramWebController(headless=True)
    driver = controller.driver

    try:
        # Load local origin
        driver.get("http://127.0.0.1:8999")
        
        # Read injector script
        injector_path = os.path.join(os.path.dirname(__file__), "injector.js")
        with open(injector_path, "r", encoding="utf-8") as f:
            injector_script = f.read()

        payload = {
            "dc_id": decoded_v4["dc_id"],
            "auth_key_array": decoded_v4["auth_key_list"],
            "user_id": "987654321",
            "server_time_offset": 0
        }

        result = driver.execute_async_script(injector_script, payload)
        print(f"  [+] Injection execution result: {result}")
        assert result and result.get("success") is True, f"Injection failed: {result}"

        # Verify localStorage Tier 1 (Official Telegram Web A keys)
        stored_acc = driver.execute_script("return localStorage.getItem('account1');")
        assert stored_acc is not None, "account1 not found in localStorage"
        acc_obj = json.loads(stored_acc)
        assert acc_obj["userId"] == "987654321", "User ID mismatch in account1"
        assert acc_obj["dcId"] == 2, "DC ID mismatch in account1"
        assert "dc2_auth_key" in acc_obj, "Auth key missing in account1"
        print("  [OK] localStorage verified: account1 exists with valid dcId, userId, and dc2_auth_key")

        # Verify IndexedDB Tier 2
        idb_check_script = """
        const done = arguments[0];
        const req = indexedDB.open('tt-data');
        req.onsuccess = function(e) {
            const db = e.target.result;
            try {
                const tx = db.transaction('keyval', 'readonly');
                const store = tx.objectStore('keyval');
                const getReq = store.get('dc2_auth_key');
                getReq.onsuccess = function() {
                    const val = getReq.result;
                    db.close();
                    if (val && val.length === 256) {
                        done({ exists: true, length: val.length });
                    } else {
                        done({ exists: false, error: 'Key not found or invalid length' });
                    }
                };
                getReq.onerror = () => { db.close(); done({ exists: false, error: 'Get error' }); };
            } catch(err) {
                db.close();
                done({ exists: false, error: String(err) });
            }
        };
        req.onerror = () => done({ exists: false, error: 'Open error' });
        """
        idb_result = driver.execute_async_script(idb_check_script)
        print(f"  [+] IndexedDB key verification: {idb_result}")
        assert idb_result.get("exists") is True, f"IndexedDB verification failed: {idb_result}"
        assert idb_result.get("length") == 256, "Auth key length in IndexedDB is not 256 bytes"
        print("  [OK] IndexedDB verified: 'dc2_auth_key' exists with exactly 256 bytes buffer.")

        # -------------------------------------------------------------
        # 3. Test ActionChains Scrolling Simulation
        # -------------------------------------------------------------
        print("\n[TEST 3] Testing ActionChains Scrolling Simulation...")
        controller.simulate_channel_reading("/test-channel", duration_seconds=3)
        print("  [OK] Channel scrolling simulation executed without errors.")

        # Verify Dashboard Detection
        assert controller.wait_for_dashboard(timeout=5) is True, "Dashboard detection failed."
        print("  [OK] Dashboard presence detection verified.")

    finally:
        controller.close()
        server.shutdown()

    print("\n==================================================================")
    print("ALL TESTS PASSED SUCCESSFULLY! PIPELINE IS VERIFIED AND READY.")
    print("==================================================================")


if __name__ == "__main__":
    run_tests()
