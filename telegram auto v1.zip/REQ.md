================================================================================
TELEGRAM CLIENT AUTOMATION AND SESSION INJECTION SYSTEM: TECHNICAL ARCHITECTURE
================================================================================

1. CORE ENTITIES & CREDENTIAL ACQUISITION
* Purpose: Setting up a standalone application connected to the official Telegram ecosystem.
* Authentication Requirements: Official MTProto communication requires an `api_id` (integer) and an `api_hash` (hexadecimal string).
* Verification Source: Generated via the official developer management portal at https://my.telegram.org.
* Critical Authorization Binding:
  - MTProto cryptographic authorization keys (`auth_key`) generated during login (`auth.sendCode` / `auth.signIn`) are permanently bound by Telegram's servers to the specific `api_id` used during the handshake.
  - To prevent `AUTH_KEY_UNREGISTERED` or `SESSION_REVOKED` errors when reusing sessions across different frontends, the local web client MUST be built and configured with the exact same `api_id` and `api_hash` that generated the underlying Telethon session.
  - One developer `api_id` and `api_hash` pair can authenticate and manage multiple phone numbers and sessions simultaneously.

2. HYBRID MODEL ARCHITECTURE
* Concept: Decoupling the visual presentation tier from the programmatic execution engine.
* UI Frontend Layer: Employs a self-hosted, locally executed clone of official web clients:
  - Telegram Web A (Ajaxy/telegram-tt, React/Teact based) running on `http://localhost:8080` (or similar local host).
  - Telegram Web K (morethanwords/tweb) running on `http://localhost:8081`.
  - The client is built with matching `API_ID` and `API_HASH` in its environment configuration.
* Backend Automation Layer: Powered by Python's Telethon MTProto engine.
* Integration Vector: The backend orchestrates browser instances via Undetected Chromedriver, performing session hydration into the browser storage before dashboard startup, or triggering actions directly via MTProto RPC when high throughput is needed.

3. SESSIONS & DUAL-TIER OTP-BYPASS IMPLEMENTATION
* Mechanism: Bypassing SMS/app verification codes (`send_code_request`) by directly importing pre-authorized session keys.
* Persistent Auth State: Utilizing an explicit string-based session block (`StringSession`) containing the pre-authorized cryptographic auth key and data center ID.
* Architectural Pipeline:
  [Telethon Base64 StringSession]
          │
          ▼
  [Python Binary Decoder] ──► Extracts: dc_id, server_ip, port, auth_key (256 bytes)
          │
          ▼
  [Pre-flight Verification] ──► Validates auth_key with Telegram DC & retrieves currentUserId
          │
          ▼
  [Dual-Tier Storage Injector]
    ├─► Tier 1: IndexedDB ('tt-data' / 'keyval') ──► Writes 'dc{dc_id}_auth_key' (Uint8Array)
    └─► Tier 2: localStorage ('tt-global-state') ──► Writes 'authState: authorizationStateReady' & 'currentUserId'
          │
          ▼
  [Page Reload / Client Init] ──► Browser immediately renders authenticated account dashboard without OTP.

* Alternative Native Bridge (Local Clone Hook):
  Because the frontend is a self-hosted clone powered by GramJS/MTProto, a native JS bridge can be exposed on `window`:
  ```javascript
  window.loadTelethonSession = async function(stringSession) {
      const { TelegramClient } = window.gramjs;
      const { StringSession } = window.gramjs.sessions;
      const client = new TelegramClient(new StringSession(stringSession), window.API_ID, window.API_HASH);
      await client.connect();
      window.location.reload();
  };
  ```

4. TELETHON SESSION DECODING MECHANISM
* Data Structures: A standard Telethon session string contains connection metrics and credentials packed into a URL-safe Base64 stream.
* Byte Packing Scheme:
  - The parser drops the version prefix (character "1").
  - Decodes remaining characters via standard URL-safe Base64 with proper padding (`=`).
  - Unpacks elements using Python's `struct` module:
    * IPv4 Sessions (263 bytes total): `struct.unpack('>B4sH256s', data)`
      - `dc_id` -> 1 Byte unsigned char
      - `ip_address` -> 4 Bytes packed network order (`socket.inet_ntoa`)
      - `port` -> 2 Bytes unsigned short (`H`)
      - `auth_key` -> 256 Bytes binary key
    * IPv6 Sessions (275 bytes total): `struct.unpack('>B16sH256s', data)`
      - `dc_id` -> 1 Byte unsigned char
      - `ip_address` -> 16 Bytes packed network order (`socket.inet_ntop(AF_INET6)`)
      - `port` -> 2 Bytes unsigned short (`H`)
      - `auth_key` -> 256 Bytes binary key

5. BROWSER CONTROLLER & SESSION INJECTION METHOD
* Controller Configuration: Executed via Python `undetected_chromedriver` (uc) to suppress `navigator.webdriver`, patch Chrome runtime flags, and evade anti-bot screening.
* Target Storage Engines:
  1. IndexedDB (`tt-data` database, `keyval` object store):
     - Key: `"dc" + dc_id + "_auth_key"`
     - Value: `Uint8Array` containing the 256-byte `auth_key`.
     - Key: `"server_time_offset"` -> 0 (or synchronized offset).
  2. LocalStorage (`tt-global-state`):
     - Key: `"tt-global-state"`
     - Value: JSON serialized state containing:
       ```json
       {
         "currentUserId": "<user_id>",
         "auth": {
           "authState": "authorizationStateReady"
         }
       }
       ```
* Injection Procedure:
  1. Browser navigates to the local clone origin (`driver.get("http://localhost:8080")`).
  2. Browser executes injection JavaScript via `driver.execute_async_script(...)` to write to IndexedDB and `localStorage`.
  3. Browser executes `driver.refresh()` (or `window.location.reload()`).
  4. The client's state machine loads the pre-configured session and opens the account interface directly.

6. CHANNEL VISIT AUTOMATION & VIEW MANIPULATION LOGIC
* Monetization & View Attribution:
  - Channel post views and ad impressions are registered when the client views content.
* Dual Execution Modes:
  - Mode A: Visual User Emulation (Selenium ActionChains)
    * Smooth variable scrolling down the channel context tree via `window.scrollBy({top: delta, behavior: 'smooth'})`.
    * Realistic mouse drifts and hover movements to prevent static cursor flags.
    * Randomized pacing constraints: `time.sleep(random.uniform(2.5, 6.0))` emulating human reading behavior.
  - Mode B: Native Protocol Execution (Telethon MTProto RPC)
    * For batch operations or background view logging, execute direct MTProto RPC:
      `client(GetMessagesViewsRequest(peer=channel, id=message_ids, increment=True))`
    * Operates in milliseconds with 99% less CPU and memory overhead than browser rendering.

7. SECURITY MITIGATION & ANTI-MULTI-BAN PROTOCOLS
* Detection Vectors: Telegram's anti-fraud systems track IP clustering, rapid consecutive queries, device fingerprint hops, and headless browser anomalies.
* Safeguards & Protocols:
  - Dedicated Proxy Isolation: Each session must be assigned a unique residential or mobile SOCKS5/HTTP proxy. Never run multiple sessions from a single datacenter IP.
  - Anti-Headless Directive: Always use patched browser engines (`undetected_chromedriver`) with realistic viewport dimensions, user-agent rotation, and WebGL noise.
  - Session Integrity Rule: Closing an automation instance must strictly invoke `driver.quit()`. Never trigger the UI "Log Out" routine; doing so sends `auth.logOut` to the MTProto server, permanently revoking the `auth_key`.
  - Fingerprint Consistency: Match the browser's user-agent platform and language with the MTProto client parameters (`device_model`, `system_version`, `app_version`).
================================================================================
